<?php

namespace App\Facades;

use Illuminate\Support\Facades\Facade;

/**
*
*@author : Tiamiyu waliu
*@website : http://www.iDocrea8.com
*/
class Addon extends Facade
{
    protected static function getFacadeAccessor(){return 'addon';}
}
