<?php
return [
    'name' => 'URL Shortener',
    'slug' => 'urlshortener',
    'description' => 'URL Shortener is an addon that replace url in user content with short urls, making your site look good'
];