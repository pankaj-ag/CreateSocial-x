<?php

return [
    'testing-list' => [
        'type' => 'int',
        'title' => 'Users listing limit',
        'description' => 'Users listing limit',
        'value' => '10',
    ],
];