<?php
return [
    'name' => 'Test Addon',
    'slug' => 'test',
    'description' => 'A testing addon'
];