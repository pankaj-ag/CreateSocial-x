<?php
return [
    'online-members' => 'Online Members',
    'men' => 'Men',
    'women' => 'Women',
    'all' => 'All',
    'no-member' => 'No one is online check by later',
];