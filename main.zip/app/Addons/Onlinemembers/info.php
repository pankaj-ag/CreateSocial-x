<?php
return [
    'name' => 'Online Members',
    'slug' => 'onlinemembers',
    'description' => 'An Addon to list online members or have online member directory '
];