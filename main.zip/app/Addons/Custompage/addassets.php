<?php


Theme::asset()->add('custompage-css', 'custompage::css/custompage.css');
//Theme::asset()->add('custompage-js', 'custompage::js/custompage.js');