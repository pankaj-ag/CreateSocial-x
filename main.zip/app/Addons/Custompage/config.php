<?php

return [

    'enable-recent-pages' => [
        'type' => 'boolean',
        'title' => 'Enable Recent Pages',
        'description' => 'Option to enable recent pages on the side bar',
        'value' => '1',
    ],

];