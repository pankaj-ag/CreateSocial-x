<?php
return [
    'name' => 'Custom Page Addon',
    'slug' => 'custompage',
    'description' => 'An addon to allow creation of more pages'
];