<?php
return [
    'name' => 'Custom Widgets',
    'slug' => 'customwidget',
    'description' => 'An Addon allowing you to easily add more widgets to different pages'
];