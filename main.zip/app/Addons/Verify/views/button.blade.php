<ul class="nav user-action-buttons">
    <li><a href="{{URL::route('verify-get')}}" data-ajaxify="true"><i class="icon ion-ios7-person"></i> <span>Get Verify Badge</span></a> </li>

</ul>