<?php
return [
    'name' => 'Verify Badge',
    'slug' => 'verify',
    'description' => 'An Addon for members to get verified badge with there purchase cde'
];