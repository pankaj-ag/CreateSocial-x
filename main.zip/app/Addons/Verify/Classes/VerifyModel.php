<?php
namespace App\Addons\Verify\Classes;
use Illuminate\Database\Eloquent\Model;

/**
*
*@author: Tiamiyu waliu kola
*@website : www.crea8social.com
*/
class VerifyModel extends Model
{
    protected $table = "verified_codes";
}