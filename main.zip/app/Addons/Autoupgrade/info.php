<?php
return [
    'name' => 'Autoupgrade',
    'slug' => 'autoupgrade',
    'description' => 'An Addon to auto upgrade your crea8social version'
];