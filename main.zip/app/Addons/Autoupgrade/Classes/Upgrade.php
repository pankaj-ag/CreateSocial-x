<?php
namespace App\Addons\Autoupgrade\Classes;
use Illuminate\Database\Eloquent\Model;

/**
*
*@author: Tiamiyu waliu kola
*@website : www.crea8social.com
*/
class Upgrade extends Model
{
    protected $table = "upgraded_versions";
}