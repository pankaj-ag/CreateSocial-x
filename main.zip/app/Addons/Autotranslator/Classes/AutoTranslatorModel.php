<?php

namespace App\Addons\Autotranslator\Classes;
use Illuminate\Database\Eloquent\Model;

/**
*
*@author: Tiamiyu waliu kola
*@website : www.crea8social.com
*/
class AutoTranslatorModel extends Model
{
    protected $table = "translated_text";
}