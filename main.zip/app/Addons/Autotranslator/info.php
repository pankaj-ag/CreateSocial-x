<?php
return [
    'name' => 'AutoTranslator Addon',
    'slug' => 'autotranslator',
    'description' => 'AutoTranslator is a translator system that can be use to translate non-english language in post bodies'
];