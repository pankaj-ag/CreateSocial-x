<?php
return [
    'name' => 'Ctrlenter',
    'slug' => 'ctrlenter',
    'description' => 'Send posts press crtl+enter, Send message press enter'
];