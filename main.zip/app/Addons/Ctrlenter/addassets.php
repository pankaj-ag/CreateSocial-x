<?php
Theme::asset()->add('ctrlenter-js', 'ctrlenter::js/ctrlenter.js');