<?php
return [
    'list' => [
        '1' => 'month.january',
        '2' => 'month.february',
        '3' => 'month.march',
        '4' => 'month.april',
        '5' => 'month.may',
        '6' => 'month.june',
        '7' => 'month.july',
        '8' => 'month.august',
        '9' => 'month.september',
        '10'=> 'month.october',
        '11'=> 'month.november',
        '12'=> 'month.december'
    ]
];