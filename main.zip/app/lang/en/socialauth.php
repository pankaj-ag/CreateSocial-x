<?php

return [
  'need-info' => 'A following Information need your attention',
    'info-note' => 'Below fields are already used by other members or your social service provider does not grant access to it,
                <strong>Please kindly modify them to continue</strong>',

    'info.note' => 'Below fields are already used by other members or your social service provider does not grant access to it,
                <strong>Please kindly modify them to continue</strong>'

];