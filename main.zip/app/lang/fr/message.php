<?php
return [
    'sent' => 'Message sent successfully',
    'messages' => 'Messages',
    'send' => 'Send',
    'write-message' => 'Write message',
    'conversations' => 'Conversations',
    'no-friends' => 'No friends is online',
    'friends-online' => 'Friends online',
    'send-message' => 'Send Message',

];