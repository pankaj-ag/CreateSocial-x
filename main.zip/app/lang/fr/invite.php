<?php
return [
    'invite-friends' => 'Invite Frineds',
    'success' => "<strong>Thanks!!</strong>Invitation sent to them",
    'invite-note' => '<strong>Invite your friends</strong> to join you here, any moment they register, they will be added to your friends list',
    'message-note' => 'Seperate multiple emails with a comma',
    'send-invitation' => 'Send Invitation'
];