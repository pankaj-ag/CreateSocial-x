<?php
return [
    'view-more-comment' => 'Voir plus de commentaires',
    'post-a-comment' => 'Ajouter un commentaire',
    'confirm-delete' => 'Voulez-vous vraiment supprimer ce',
    'comments' => 'commentaires',
];