<?php
return [
    'photo' => 'photo',
    'photos' => 'Photos',
    'recent-photos' => 'Recent photos',
    'add-album' => 'Add Album',
    'album-name' => 'Album name',

];