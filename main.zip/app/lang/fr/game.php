<?php
return [
    'games' => 'dfsdfdsf',
    'game' => 'ewrfsdfs',
    'add-games' => 'Add Games',
    'add-game' => 'Add Game',
    'add-a-game' => 'Add a Game',
    'find-games' => 'Find Games',
    'my-games' => 'My Games',
    'filter-category' => 'Filter by category',
    'no-game' => 'There are no games at this moment',
    'add-game-info' => 'Add Your games with there full details from here',

    'title' => 'Game Title',
    'about' => 'Game About',
    'category' => 'Game category',
    'content' => 'Game content',
    'edit-game' => 'Edit Game',
    'edit-info' => 'Edit Your games with there full details from here',
    'change-icon' => 'Change Icon',
    'save-game' => 'Save Game'

];